/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 6;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.968172983479106, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.5, 500, 1500, "cadu - 1.2 - \/login\/autenticar-0"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 2.1 - \/home-4"], "isController": false}, {"data": [1.0, 500, 1500, "cadu - 1.2 - \/login\/autenticar-1"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 2.1 - \/home-3"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 2.1 - \/home-2"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 2.1 - \/home-1"], "isController": false}, {"data": [0.55, 500, 1500, "mlocf - 2.1 - \/home-0"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 3.1 Tela Lotes-6"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 3.1 Tela Lotes-7"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 3.1 Tela Lotes-8"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 3.1 Tela Lotes-9"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 3.1 Tela Lotes-2"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 3.1 Tela Lotes-3"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 3.1 Tela Lotes-4"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 2.1 - \/home-9"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 3.1 Tela Lotes-5"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 2.1 - \/home-8"], "isController": false}, {"data": [1.0, 500, 1500, "cadu - 4.2 - CADU - Logout-0"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 2.1 - \/home-7"], "isController": false}, {"data": [1.0, 500, 1500, "cadu - 4.2 - CADU - Logout-1"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 2.1 - \/home-6"], "isController": false}, {"data": [0.95, 500, 1500, "mlocf - 3.1 Tela Lotes-0"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 2.1 - \/home-5"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 3.1 Tela Lotes-1"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 3.1 Tela Lotes-10"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 3.1 Tela Lotes-11"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 3.1 Tela Lotes-12"], "isController": false}, {"data": [0.875, 500, 1500, "mlocf - 3.6 Tela Lotes"], "isController": false}, {"data": [0.5, 500, 1500, "cadu - 1.5 - \/gerarToken\/MLOC-0"], "isController": false}, {"data": [0.825, 500, 1500, "mlocf - 3.3 Enviar Arquivo"], "isController": false}, {"data": [0.0, 500, 1500, "cadu - 1.5 - \/gerarToken\/MLOC-1"], "isController": false}, {"data": [0.0, 500, 1500, "cadu - 1.5 - \/gerarToken\/MLOC-2"], "isController": false}, {"data": [1.0, 500, 1500, "cadu - 4.2 - CADU - Logout"], "isController": false}, {"data": [1.0, 500, 1500, "cadu - 1.4 - \/produtos"], "isController": false}, {"data": [0.0, 500, 1500, "cadu - 1.5 - \/gerarToken\/MLOC"], "isController": false}, {"data": [0.9375, 500, 1500, "mlocf - 3.7 Tela Detalhes Lote"], "isController": false}, {"data": [0.95, 500, 1500, "mlocf - 3.1 Tela Lotes"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 4.1 - CETIP | Locadora - Logout"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 3.6 Tela Lotes-4"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 3.6 Tela Lotes-3"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 3.6 Tela Lotes-6"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 3.6 Tela Lotes-5"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 3.6 Tela Lotes-8"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 3.6 Tela Lotes-7"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 3.6 Tela Lotes-9"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 2.1 - \/home-13"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 2.1 - \/home-12"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 2.1 - \/home-11"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 2.1 - \/home-10"], "isController": false}, {"data": [0.5, 500, 1500, "cadu - 1.1 - \/login"], "isController": false}, {"data": [0.5, 500, 1500, "cadu - 1.2 - \/login\/autenticar"], "isController": false}, {"data": [0.9375, 500, 1500, "mlocf - 3.6 Tela Lotes-0"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 3.6 Tela Lotes-2"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 3.6 Tela Lotes-1"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 3.1 Tela Lotes-13"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 3.1 Tela Lotes-14"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 3.1 Tela Lotes-15"], "isController": false}, {"data": [0.5125, 500, 1500, "mlocf - 2.1 - \/home"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 3.6 Tela Lotes-11"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 3.6 Tela Lotes-10"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 3.6 Tela Lotes-13"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 3.6 Tela Lotes-12"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 2.1 - \/home-15"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 2.1 - \/home-14"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 3.6 Tela Lotes-14"], "isController": false}, {"data": [1.0, 500, 1500, "mlocf - 3.2 Tela Upload"], "isController": false}, {"data": [0.0, 500, 1500, "cadu - 1.3 - \/duplaChecagem"], "isController": false}, {"data": [1.0, 500, 1500, "cadu - 1.3 - \/duplaChecagem-1"], "isController": false}, {"data": [0.0, 500, 1500, "cadu - 1.3 - \/duplaChecagem-0"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 2058, 0, 0.0, 125.50971817298341, 5, 6624, 245.10000000000014, 517.1499999999999, 1762.6400000000085, 5.452262238447721, 38.87098448701577, 7.517876471521334], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["cadu - 1.2 - \/login\/autenticar-0", 1, 0, 0.0, 778.0, 778, 778, 778.0, 778.0, 778.0, 1.2853470437017993, 0.719242046915167, 0.9627550610539846], "isController": false}, {"data": ["mlocf - 2.1 - \/home-4", 40, 0, 0.0, 42.57500000000001, 8, 174, 56.699999999999996, 73.39999999999995, 174.0, 0.11503144672174756, 0.31000076208333455, 0.06436537420448565], "isController": false}, {"data": ["cadu - 1.2 - \/login\/autenticar-1", 1, 0, 0.0, 164.0, 164, 164, 164.0, 164.0, 164.0, 6.097560975609756, 40.24152057926829, 3.096417682926829], "isController": false}, {"data": ["mlocf - 2.1 - \/home-3", 40, 0, 0.0, 35.77499999999999, 7, 157, 54.39999999999999, 60.84999999999999, 157.0, 0.11503905575943033, 0.13627465880135053, 0.06416460614941272], "isController": false}, {"data": ["mlocf - 2.1 - \/home-2", 40, 0, 0.0, 35.875000000000014, 7, 148, 53.9, 73.59999999999997, 148.0, 0.11502979271631353, 0.10878965112901742, 0.06467898330198772], "isController": false}, {"data": ["mlocf - 2.1 - \/home-1", 40, 0, 0.0, 30.3, 8, 54, 46.9, 50.89999999999999, 54.0, 0.11503012351359512, 0.2223344689562454, 0.06355021154758653], "isController": false}, {"data": ["mlocf - 2.1 - \/home-0", 40, 0, 0.0, 1128.7749999999999, 309, 3532, 2003.9999999999998, 3065.949999999999, 3532.0, 0.1148240751638396, 2.5731217427639304, 0.045175536407843636], "isController": false}, {"data": ["mlocf - 3.1 Tela Lotes-6", 40, 0, 0.0, 20.625, 7, 38, 34.599999999999994, 36.949999999999996, 38.0, 0.11528806163299775, 0.047849049017601605, 0.09417255776652439], "isController": false}, {"data": ["mlocf - 3.1 Tela Lotes-7", 40, 0, 0.0, 13.549999999999999, 6, 40, 31.799999999999997, 38.699999999999974, 40.0, 0.1152993603767983, 0.04785373843763602, 0.09489959317341312], "isController": false}, {"data": ["mlocf - 3.1 Tela Lotes-8", 40, 0, 0.0, 14.275000000000002, 6, 40, 30.799999999999997, 38.64999999999997, 40.0, 0.11530035743110804, 0.047854152254121984, 0.09557881680214458], "isController": false}, {"data": ["mlocf - 3.1 Tela Lotes-9", 40, 0, 0.0, 16.8, 6, 44, 32.8, 39.0, 44.0, 0.11529371072807978, 0.04785139361272842, 0.09569997243759729], "isController": false}, {"data": ["mlocf - 3.1 Tela Lotes-2", 40, 0, 0.0, 19.325, 6, 43, 35.29999999999999, 37.0, 43.0, 0.1152933784130443, 0.047851255689007645, 0.09544918120083819], "isController": false}, {"data": ["mlocf - 3.1 Tela Lotes-3", 40, 0, 0.0, 18.824999999999996, 8, 43, 32.9, 40.89999999999999, 43.0, 0.11529537233199302, 0.047852083243258826, 0.09493008866934728], "isController": false}, {"data": ["mlocf - 3.1 Tela Lotes-4", 40, 0, 0.0, 19.624999999999996, 7, 37, 34.9, 36.0, 37.0, 0.11529404304503096, 0.04785153153724429, 0.09513447428798721], "isController": false}, {"data": ["mlocf - 2.1 - \/home-9", 40, 0, 0.0, 33.724999999999994, 6, 86, 40.0, 43.84999999999999, 86.0, 0.11506155793349443, 0.35508120379559316, 0.06527271387067081], "isController": false}, {"data": ["mlocf - 3.1 Tela Lotes-5", 40, 0, 0.0, 17.85, 7, 41, 29.0, 33.84999999999999, 41.0, 0.11529404304503096, 0.04785153153724429, 0.09612809726637823], "isController": false}, {"data": ["mlocf - 2.1 - \/home-8", 40, 0, 0.0, 36.774999999999984, 27, 92, 46.0, 66.9499999999999, 92.0, 0.11506122695539364, 1.2342900973993285, 0.06481744996994025], "isController": false}, {"data": ["cadu - 4.2 - CADU - Logout-0", 1, 0, 0.0, 103.0, 103, 103, 103.0, 103.0, 103.0, 9.70873786407767, 5.356871966019418, 0.0], "isController": false}, {"data": ["mlocf - 2.1 - \/home-7", 40, 0, 0.0, 37.24999999999999, 29, 63, 48.0, 55.699999999999974, 63.0, 0.11504600402085784, 0.1541970355161395, 0.06413477675322919], "isController": false}, {"data": ["cadu - 4.2 - CADU - Logout-1", 1, 0, 0.0, 92.0, 92, 92, 92.0, 92.0, 92.0, 10.869565217391305, 204.2395550271739, 0.0], "isController": false}, {"data": ["mlocf - 2.1 - \/home-6", 40, 0, 0.0, 41.449999999999996, 8, 163, 50.599999999999994, 61.599999999999966, 163.0, 0.1150304543127793, 0.7993661732099824, 0.0634071679070784], "isController": false}, {"data": ["mlocf - 3.1 Tela Lotes-0", 40, 0, 0.0, 274.925, 84, 2787, 401.2, 684.1999999999992, 2787.0, 0.11522927745481572, 4.93741137248152, 0.07730714219868984], "isController": false}, {"data": ["mlocf - 2.1 - \/home-5", 40, 0, 0.0, 40.85, 12, 118, 53.39999999999999, 57.89999999999999, 118.0, 0.11503210833723963, 0.2926775188077497, 0.0653571099908262], "isController": false}, {"data": ["mlocf - 3.1 Tela Lotes-1", 40, 0, 0.0, 20.174999999999997, 8, 60, 32.0, 40.79999999999998, 60.0, 0.11529304609992448, 0.22284265543664358, 0.09398241006421823], "isController": false}, {"data": ["mlocf - 3.1 Tela Lotes-10", 40, 0, 0.0, 12.924999999999997, 6, 34, 28.799999999999983, 31.949999999999996, 34.0, 0.1152933784130443, 0.05578049023465085, 0.09569969659826888], "isController": false}, {"data": ["mlocf - 3.1 Tela Lotes-11", 40, 0, 0.0, 18.675, 6, 54, 34.599999999999994, 47.49999999999996, 54.0, 0.11529969272631889, 0.054854616996039454, 0.09571338261914782], "isController": false}, {"data": ["mlocf - 3.1 Tela Lotes-12", 40, 0, 0.0, 16.099999999999998, 6, 51, 31.0, 35.79999999999998, 51.0, 0.1152993603767983, 0.1446224423359074, 0.09241682862623694], "isController": false}, {"data": ["mlocf - 3.6 Tela Lotes", 40, 0, 0.0, 432.65000000000003, 169, 3674, 602.8, 835.9499999999991, 3674.0, 0.11540647603440267, 5.615429489708627, 1.4061783217590256], "isController": false}, {"data": ["cadu - 1.5 - \/gerarToken\/MLOC-0", 1, 0, 0.0, 767.0, 767, 767, 767.0, 767.0, 767.0, 1.303780964797914, 0.7664806062581486, 0.47363917861799215], "isController": false}, {"data": ["mlocf - 3.3 Enviar Arquivo", 40, 0, 0.0, 467.65000000000003, 109, 2254, 885.1999999999998, 1320.4999999999982, 2254.0, 0.11525650334820142, 0.3292238987241105, 0.4011691691734956], "isController": false}, {"data": ["cadu - 1.5 - \/gerarToken\/MLOC-1", 1, 0, 0.0, 4238.0, 4238, 4238, 4238.0, 4238.0, 4238.0, 0.23596035865974518, 0.1253539405379896, 0.06405955049551675], "isController": false}, {"data": ["cadu - 1.5 - \/gerarToken\/MLOC-2", 1, 0, 0.0, 1617.0, 1617, 1617, 1617.0, 1617.0, 1617.0, 0.6184291898577613, 13.558939200680273, 0.1992984693877551], "isController": false}, {"data": ["cadu - 4.2 - CADU - Logout", 1, 0, 0.0, 195.0, 195, 195, 195.0, 195.0, 195.0, 5.128205128205129, 99.18870192307692, 0.0], "isController": false}, {"data": ["cadu - 1.4 - \/produtos", 1, 0, 0.0, 351.0, 351, 351, 351.0, 351.0, 351.0, 2.849002849002849, 17.6727207977208, 1.2297453703703705], "isController": false}, {"data": ["cadu - 1.5 - \/gerarToken\/MLOC", 1, 0, 0.0, 6624.0, 6624, 6624, 6624.0, 6624.0, 6624.0, 0.15096618357487923, 3.4788564783363527, 0.14447935537439613], "isController": false}, {"data": ["mlocf - 3.7 Tela Detalhes Lote", 40, 0, 0.0, 316.925, 79, 2290, 525.1999999999999, 976.1499999999982, 2290.0, 0.11545011112073195, 2.3167815756053916, 0.12005007648569861], "isController": false}, {"data": ["mlocf - 3.1 Tela Lotes", 40, 0, 0.0, 329.04999999999995, 111, 2871, 472.29999999999995, 731.7999999999993, 2871.0, 0.11521367816787209, 5.893880033937629, 1.4048192801449388], "isController": false}, {"data": ["mlocf - 4.1 - CETIP | Locadora - Logout", 1, 0, 0.0, 143.0, 143, 143, 143.0, 143.0, 143.0, 6.993006993006993, 157.069493006993, 0.0], "isController": false}, {"data": ["mlocf - 3.6 Tela Lotes-4", 40, 0, 0.0, 39.975000000000016, 8, 70, 48.0, 49.949999999999996, 70.0, 0.11546110836890978, 0.04792087017264322, 0.09527796540207888], "isController": false}, {"data": ["mlocf - 3.6 Tela Lotes-3", 40, 0, 0.0, 35.37499999999999, 7, 69, 46.9, 47.949999999999996, 69.0, 0.11547244105853587, 0.047925573681521234, 0.09506178497299388], "isController": false}, {"data": ["mlocf - 3.6 Tela Lotes-6", 40, 0, 0.0, 40.39999999999999, 29, 72, 47.699999999999996, 51.89999999999999, 72.0, 0.11546044180938057, 0.04792059352440112, 0.09426262632093961], "isController": false}, {"data": ["mlocf - 3.6 Tela Lotes-5", 40, 0, 0.0, 40.82500000000001, 28, 65, 50.599999999999994, 59.54999999999996, 65.0, 0.11545977525754746, 0.0479203168793532, 0.0962916485058062], "isController": false}, {"data": ["mlocf - 3.6 Tela Lotes-8", 40, 0, 0.0, 37.74999999999999, 9, 63, 49.8, 55.74999999999998, 63.0, 0.11546677443565614, 0.04792322181167369, 0.09573368310143755], "isController": false}, {"data": ["mlocf - 3.6 Tela Lotes-7", 40, 0, 0.0, 35.8, 29, 62, 42.0, 45.89999999999999, 62.0, 0.1154644412820017, 0.047922253461768274, 0.09505519921946037], "isController": false}, {"data": ["mlocf - 3.6 Tela Lotes-9", 40, 0, 0.0, 34.89999999999999, 7, 52, 44.699999999999996, 49.89999999999999, 52.0, 0.11547110768546825, 0.04792502027961329, 0.09585004055922658], "isController": false}, {"data": ["mlocf - 2.1 - \/home-13", 40, 0, 0.0, 19.725, 7, 42, 33.9, 34.0, 42.0, 0.11509996431901107, 0.04953569753455876, 0.06227087913352747], "isController": false}, {"data": ["mlocf - 2.1 - \/home-12", 40, 0, 0.0, 30.149999999999988, 8, 54, 39.8, 46.74999999999998, 54.0, 0.11508804235239958, 1.1874101998575786, 0.06199750133070549], "isController": false}, {"data": ["mlocf - 2.1 - \/home-11", 40, 0, 0.0, 29.975, 7, 52, 37.0, 43.949999999999996, 52.0, 0.11508704896666216, 0.21581631423655567, 0.06473084555893464], "isController": false}, {"data": ["mlocf - 2.1 - \/home-10", 40, 0, 0.0, 32.24999999999999, 8, 61, 42.8, 45.84999999999999, 61.0, 0.11507579179336991, 0.16151348130881452, 0.06441828198315866], "isController": false}, {"data": ["cadu - 1.1 - \/login", 1, 0, 0.0, 1379.0, 1379, 1379, 1379.0, 1379.0, 1379.0, 0.7251631617113851, 13.769602066715011, 0.2698116841914431], "isController": false}, {"data": ["cadu - 1.2 - \/login\/autenticar", 1, 0, 0.0, 944.0, 944, 944, 944.0, 944.0, 944.0, 1.0593220338983051, 7.5838767876059325, 1.3313940015889831], "isController": false}, {"data": ["mlocf - 3.6 Tela Lotes-0", 40, 0, 0.0, 345.32500000000005, 93, 3570, 513.9, 719.2499999999993, 3570.0, 0.11543178702835293, 4.945939258531131, 0.07744300555515475], "isController": false}, {"data": ["mlocf - 3.6 Tela Lotes-2", 40, 0, 0.0, 28.775000000000002, 8, 55, 44.9, 47.949999999999996, 55.0, 0.11546477458389381, 0.04792239179507312, 0.09561926645228708], "isController": false}, {"data": ["mlocf - 3.6 Tela Lotes-1", 40, 0, 0.0, 33.39999999999999, 7, 68, 48.8, 61.64999999999997, 68.0, 0.1154594419845169, 0.04792017855802703, 0.094487316780298], "isController": false}, {"data": ["mlocf - 3.1 Tela Lotes-13", 40, 0, 0.0, 15.849999999999996, 7, 69, 28.799999999999997, 32.84999999999999, 69.0, 0.11530201922661171, 0.04785484196416989, 0.09299884788060475], "isController": false}, {"data": ["mlocf - 3.1 Tela Lotes-14", 40, 0, 0.0, 13.225, 7, 56, 27.599999999999994, 33.79999999999998, 56.0, 0.1153056753453405, 0.047856359396259485, 0.09333960638245739], "isController": false}, {"data": ["mlocf - 3.1 Tela Lotes-15", 1, 0, 0.0, 17.0, 17, 17, 17.0, 17.0, 17.0, 58.8235294117647, 24.4140625, 47.62178308823529], "isController": false}, {"data": ["mlocf - 2.1 - \/home", 40, 0, 0.0, 1221.0250000000003, 383, 3628, 2119.4999999999995, 3170.6499999999987, 3628.0, 0.1147996888928431, 7.8758248088585185, 0.940166290039979], "isController": false}, {"data": ["mlocf - 3.6 Tela Lotes-11", 40, 0, 0.0, 31.4, 6, 57, 49.19999999999999, 53.79999999999998, 57.0, 0.11546310809367522, 0.04792170013653513, 0.09618167109756344], "isController": false}, {"data": ["mlocf - 3.6 Tela Lotes-10", 40, 0, 0.0, 33.199999999999996, 8, 50, 41.0, 44.79999999999998, 50.0, 0.11546277480140403, 0.04792156180722335, 0.09618139346249768], "isController": false}, {"data": ["mlocf - 3.6 Tela Lotes-13", 40, 0, 0.0, 22.900000000000002, 7, 45, 40.9, 42.0, 45.0, 0.11546410798203378, 0.04792211512926207, 0.09313804022769522], "isController": false}, {"data": ["mlocf - 3.6 Tela Lotes-12", 40, 0, 0.0, 31.375000000000004, 7, 44, 39.8, 40.0, 44.0, 0.11546410798203378, 0.04792211512926207, 0.09279976647384161], "isController": false}, {"data": ["mlocf - 2.1 - \/home-15", 1, 0, 0.0, 9.0, 9, 9, 9.0, 9.0, 9.0, 111.1111111111111, 739.9088541666667, 47.96006944444445], "isController": false}, {"data": ["mlocf - 2.1 - \/home-14", 40, 0, 0.0, 14.575, 5, 36, 30.9, 31.949999999999996, 36.0, 0.11509400302697227, 0.06876698086130598, 0.06260203353119911], "isController": false}, {"data": ["mlocf - 3.6 Tela Lotes-14", 40, 0, 0.0, 14.175, 7, 42, 30.0, 31.89999999999999, 42.0, 0.11547377446239741, 0.04792612709620986, 0.0934841396770776], "isController": false}, {"data": ["mlocf - 3.2 Tela Upload", 40, 0, 0.0, 51.12499999999999, 23, 147, 79.39999999999999, 85.94999999999999, 147.0, 0.11530068978637664, 0.3500682075643018, 0.12734871108241405], "isController": false}, {"data": ["cadu - 1.3 - \/duplaChecagem", 1, 0, 0.0, 5904.0, 5904, 5904, 5904.0, 5904.0, 5904.0, 0.16937669376693767, 1.1446159383468835, 0.17466971544715448], "isController": false}, {"data": ["cadu - 1.3 - \/duplaChecagem-1", 1, 0, 0.0, 107.0, 107, 107, 107.0, 107.0, 107.0, 9.345794392523365, 57.973130841121495, 4.4812353971962615], "isController": false}, {"data": ["cadu - 1.3 - \/duplaChecagem-0", 1, 0, 0.0, 5796.0, 5796, 5796, 5796.0, 5796.0, 5796.0, 0.1725327812284334, 0.09570177708764664, 0.09519630995514147], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 2058, 0, null, null, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
